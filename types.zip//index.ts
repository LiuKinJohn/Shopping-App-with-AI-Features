export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  tags: string[];
  rating: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface DetectedProduct {
  product: Product;
  confidence: number;
}

export interface RedNotePost {
  id: string;
  productId: string;
  author: string;
  authorAvatar: string;
  content: string;
  images: string[];
  likes: number;
  comments: number;
  timestamp: Date;
  tags: string[];
}

export interface RedNoteComment {
  id: string;
  postId: string;
  author: string;
  content: string;
  likes: number;
  timestamp: Date;
}
