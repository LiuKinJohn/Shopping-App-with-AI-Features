import { RedNotePost, RedNoteComment } from "../types";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Heart, MessageCircle, Share2 } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface RedNoteCardProps {
  post: RedNotePost;
  comments?: RedNoteComment[];
  onClick?: () => void;
}

export function RedNoteCard({ post, comments, onClick }: RedNoteCardProps) {
  const displayComments = comments?.slice(0, 2) || [];

  return (
    <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={onClick}>
      <CardContent className="p-4">
        {/* Author Info */}
        <div className="flex items-center gap-3 mb-3">
          <img
            src={post.authorAvatar}
            alt={post.author}
            className="w-10 h-10 rounded-full"
          />
          <div className="flex-1">
            <p className="font-medium">{post.author}</p>
            <p className="text-xs text-muted-foreground">
              {post.timestamp.toLocaleDateString()}
            </p>
          </div>
          <Badge variant="secondary" className="bg-red-100 text-red-600 hover:bg-red-100">
            小红书
          </Badge>
        </div>

        {/* Content */}
        <p className="mb-3 whitespace-pre-wrap">{post.content}</p>

        {/* Images */}
        {post.images.length > 0 && (
          <div className="mb-3 grid grid-cols-2 gap-2">
            {post.images.slice(0, 4).map((img, idx) => (
              <ImageWithFallback
                key={idx}
                src={img}
                alt={`Post image ${idx + 1}`}
                className="w-full aspect-square object-cover rounded"
              />
            ))}
          </div>
        )}

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-3">
          {post.tags.map((tag) => (
            <span key={tag} className="text-sm text-blue-600">
              #{tag}
            </span>
          ))}
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 text-muted-foreground border-t pt-3">
          <div className="flex items-center gap-1">
            <Heart className="w-4 h-4" />
            <span className="text-sm">{post.likes.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <MessageCircle className="w-4 h-4" />
            <span className="text-sm">{post.comments}</span>
          </div>
          <div className="flex items-center gap-1">
            <Share2 className="w-4 h-4" />
          </div>
        </div>

        {/* Comments Preview */}
        {displayComments.length > 0 && (
          <div className="mt-3 space-y-2 bg-muted/50 rounded p-3">
            {displayComments.map((comment) => (
              <div key={comment.id} className="text-sm">
                <span className="font-medium">{comment.author}: </span>
                <span className="text-muted-foreground">{comment.content}</span>
                <div className="flex items-center gap-2 mt-1">
                  <Heart className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{comment.likes}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}