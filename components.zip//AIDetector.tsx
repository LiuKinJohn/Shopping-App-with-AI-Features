import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Upload, Loader2, Sparkles } from "lucide-react";
import { Product, DetectedProduct } from "../types";
import { products } from "../data/products";

interface AIDetectorProps {
  onProductSelect: (product: Product) => void;
}

export function AIDetector({ onProductSelect }: AIDetectorProps) {
  const [detecting, setDetecting] = useState(false);
  const [detectedProducts, setDetectedProducts] = useState<DetectedProduct[]>([]);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const simulateAIDetection = (file: File) => {
    setDetecting(true);
    setPreviewImage(URL.createObjectURL(file));

    // Simulate AI processing delay
    setTimeout(() => {
      // Mock AI detection - randomly select 2-3 products with confidence scores
      const numResults = Math.floor(Math.random() * 2) + 2;
      const shuffled = [...products].sort(() => Math.random() - 0.5);
      const results: DetectedProduct[] = shuffled.slice(0, numResults).map((product, index) => ({
        product,
        confidence: Math.max(0.7, 0.95 - index * 0.15),
      }));

      setDetectedProducts(results);
      setDetecting(false);
    }, 2000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      simulateAIDetection(file);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          AI Product Detector
        </CardTitle>
        <CardDescription>
          Upload an image to detect and find similar products
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
          <input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
            id="image-upload"
            disabled={detecting}
          />
          <label htmlFor="image-upload" className="cursor-pointer">
            {previewImage ? (
              <img src={previewImage} alt="Preview" className="max-h-48 mx-auto mb-4 rounded" />
            ) : (
              <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            )}
            <Button asChild disabled={detecting}>
              <span>
                {detecting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Upload Image"
                )}
              </span>
            </Button>
          </label>
        </div>

        {detecting && (
          <div className="text-center py-4">
            <Loader2 className="w-8 h-8 mx-auto mb-2 animate-spin text-primary" />
            <p className="text-muted-foreground">AI is analyzing your image...</p>
          </div>
        )}

        {!detecting && detectedProducts.length > 0 && (
          <div className="space-y-3">
            <h4>Detected Products:</h4>
            {detectedProducts.map(({ product, confidence }) => (
              <Card
                key={product.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => onProductSelect(product)}
              >
                <CardContent className="p-4 flex items-center gap-4">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-20 h-20 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h5>{product.name}</h5>
                    <p className="text-muted-foreground">${product.price}</p>
                  </div>
                  <Badge variant="secondary">
                    {Math.round(confidence * 100)}% match
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
