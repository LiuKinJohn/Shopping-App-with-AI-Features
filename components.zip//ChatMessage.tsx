import { Product, RedNotePost, RedNoteComment } from "../types";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Bot, User, ShoppingCart, Star } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { RedNoteCard } from "./RedNoteCard";

export interface Message {
  id: string;
  type: "user" | "ai";
  content: string;
  products?: Product[];
  redNotePosts?: RedNotePost[];
  redNoteComments?: RedNoteComment[];
  image?: string;
  timestamp: Date;
}

interface ChatMessageProps {
  message: Message;
  onAddToCart: (product: Product) => void;
  onProductClick: (product: Product) => void;
  onRedNoteClick?: (post: RedNotePost) => void;
}

export function ChatMessage({ message, onAddToCart, onProductClick, onRedNoteClick }: ChatMessageProps) {
  const isUser = message.type === "user";

  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
          isUser ? "bg-primary" : "bg-secondary"
        }`}
      >
        {isUser ? (
          <User className="w-4 h-4 text-primary-foreground" />
        ) : (
          <Bot className="w-4 h-4" />
        )}
      </div>
      <div className={`flex-1 max-w-[80%] ${isUser ? "items-end" : "items-start"} flex flex-col`}>
        <div
          className={`rounded-lg p-4 ${
            isUser
              ? "bg-primary text-primary-foreground ml-auto"
              : "bg-muted"
          }`}
        >
          {message.image && (
            <img
              src={message.image}
              alt="Uploaded"
              className="max-w-full rounded mb-2 max-h-48"
            />
          )}
          <p className="whitespace-pre-wrap">{message.content}</p>
        </div>

        {message.redNotePosts && message.redNotePosts.length > 0 && (
          <div className="mt-3 space-y-3 w-full">
            {message.redNotePosts.map((post) => (
              <RedNoteCard
                key={post.id}
                post={post}
                comments={message.redNoteComments?.filter(c => c.postId === post.id)}
                onClick={() => onRedNoteClick?.(post)}
              />
            ))}
          </div>
        )}

        {message.products && message.products.length > 0 && (
          <div className="mt-3 space-y-3 w-full">
            {message.products.map((product) => (
              <Card
                key={product.id}
                className="cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => onProductClick(product)}
              >
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <ImageWithFallback
                      src={product.image}
                      alt={product.name}
                      className="w-24 h-24 object-cover rounded flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h4 className="truncate">{product.name}</h4>
                        <Badge variant="secondary" className="flex-shrink-0">
                          {product.category}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-2">
                        {product.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-yellow-400 stroke-yellow-400" />
                            <span className="text-sm">{product.rating}</span>
                          </div>
                          <span className="text-primary">${product.price}</span>
                        </div>
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            onAddToCart(product);
                          }}
                        >
                          <ShoppingCart className="w-4 h-4 mr-1" />
                          加购
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        <span className="text-xs text-muted-foreground mt-1">
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
}