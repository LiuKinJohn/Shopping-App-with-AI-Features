import { Product } from "../types";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Sparkles, TrendingUp } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface RecommendationsProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export function Recommendations({ products, onProductClick, onAddToCart }: RecommendationsProps) {
  if (products.length === 0) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          AI Recommended For You
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {products.map((product) => (
            <Card
              key={product.id}
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => onProductClick(product)}
            >
              <CardContent className="p-4 flex items-center gap-4">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-24 h-24 object-cover rounded"
                />
                <div className="flex-1">
                  <div className="flex items-start gap-2 mb-1">
                    <h5 className="flex-1">{product.name}</h5>
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  </div>
                  <p className="text-muted-foreground mb-2 line-clamp-1">
                    {product.description}
                  </p>
                  <p className="text-primary">${product.price}</p>
                </div>
                <Button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddToCart(product);
                  }}
                  size="sm"
                >
                  Add
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
