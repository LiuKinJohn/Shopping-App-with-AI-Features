import { Product, RedNotePost, RedNoteComment } from "../types";
import { products } from "../data/products";
import { redNotePosts, redNoteComments } from "../data/redNotePosts";

export interface AIResponse {
  message: string;
  products?: Product[];
  redNotePosts?: RedNotePost[];
  redNoteComments?: RedNoteComment[];
}

export function generateAIResponse(userMessage: string, hasImage: boolean): AIResponse {
  const lowerMessage = userMessage.toLowerCase();

  // Image detection response
  if (hasImage) {
    const detectedProducts = products
      .sort(() => Math.random() - 0.5)
      .slice(0, 2);
    const relevantPosts = redNotePosts.filter(post => 
      detectedProducts.some(p => p.id === post.productId)
    );
    return {
      message: "我已经分析了你的图片！根据小红书社区的讨论，我找到了这些相关商品：",
      products: detectedProducts,
      redNotePosts: relevantPosts.slice(0, 1),
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  // Greeting
  if (
    lowerMessage.includes("你好") ||
    lowerMessage.includes("hello") ||
    lowerMessage.includes("hi") ||
    lowerMessage.includes("嗨")
  ) {
    return {
      message:
        "你好呀！👋 我是基于小红书社区洞察的AI购物助手。我会分析真实用户的评价和讨论，帮你做出最好的购物决策。\n\n你今天想找什么呀？",
    };
  }

  // Help
  if (lowerMessage.includes("帮助") || lowerMessage.includes("help")) {
    return {
      message:
        "我可以帮你：\n\n• 根据小红书社区评价推荐商品\n• 展示真实用户体验和晒图\n• 来自可信赖博主的产品推荐\n• 上传图片找相似商品\n\n有什么想问的尽管说！",
    };
  }

  // Community/review queries
  if (
    lowerMessage.includes("评价") ||
    lowerMessage.includes("评论") ||
    lowerMessage.includes("怎么说") ||
    lowerMessage.includes("社区") ||
    lowerMessage.includes("review")
  ) {
    const popularPosts = redNotePosts.sort((a, b) => b.likes - a.likes).slice(0, 3);
    return {
      message: "这些是小红书社区最热门的产品评价：",
      redNotePosts: popularPosts,
      redNoteComments: redNoteComments.filter(c => popularPosts.some(p => p.id === c.postId)),
    };
  }

  // Category searches with RedNote integration
  if (
    lowerMessage.includes("运动鞋") ||
    lowerMessage.includes("跑鞋") ||
    lowerMessage.includes("鞋") ||
    lowerMessage.includes("sneaker") ||
    lowerMessage.includes("跑步")
  ) {
    const filtered = products.filter(
      (p) => p.category === "运动鞋服" || p.tags.includes("运动鞋")
    );
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "根据小红书的真实评价，这些运动鞋超受欢迎：",
      products: filtered,
      redNotePosts: relevantPosts,
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  if (
    lowerMessage.includes("耳机") ||
    lowerMessage.includes("音频") ||
    lowerMessage.includes("音乐") ||
    lowerMessage.includes("headphone")
  ) {
    const filtered = products.filter(
      (p) => p.tags.includes("耳机") || p.tags.includes("音频")
    );
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "小红书社区都在夸这些耳机！来看看真实用户体验：",
      products: filtered,
      redNotePosts: relevantPosts,
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  if (
    lowerMessage.includes("手表") ||
    lowerMessage.includes("智能手表") ||
    lowerMessage.includes("健身") ||
    lowerMessage.includes("watch")
  ) {
    const filtered = products.filter(
      (p) => p.tags.includes("智能手表") || p.tags.includes("健身")
    );
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "小红书健身达人都在推荐这些智能手表：",
      products: filtered,
      redNotePosts: relevantPosts,
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  if (
    lowerMessage.includes("笔记本") ||
    lowerMessage.includes("电脑") ||
    lowerMessage.includes("办公") ||
    lowerMessage.includes("laptop") ||
    lowerMessage.includes("工作")
  ) {
    const filtered = products.filter(
      (p) => p.tags.includes("笔记本") || p.tags.includes("电脑")
    );
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "小红书的设计师和创意工作者都在用这款笔记本！看看他们怎么说：",
      products: filtered,
      redNotePosts: relevantPosts,
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  if (
    lowerMessage.includes("相机") ||
    lowerMessage.includes("摄影") ||
    lowerMessage.includes("拍照") ||
    lowerMessage.includes("camera")
  ) {
    const filtered = products.filter((p) => p.tags.includes("相机"));
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "小红书专业摄影师强烈推荐这些相机：",
      products: filtered,
      redNotePosts: relevantPosts,
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  if (
    lowerMessage.includes("手机") ||
    lowerMessage.includes("智能手机") ||
    lowerMessage.includes("phone")
  ) {
    const filtered = products.filter((p) => p.tags.includes("智能手机"));
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "看看小红书用户对最新手机的真实评价：",
      products: filtered,
      redNotePosts: relevantPosts,
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  if (
    lowerMessage.includes("背包") ||
    lowerMessage.includes("包") ||
    lowerMessage.includes("旅行") ||
    lowerMessage.includes("backpack")
  ) {
    const filtered = products.filter((p) => p.tags.includes("背包"));
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "小红书旅行博主都爱用这些背包：",
      products: filtered,
      redNotePosts: relevantPosts,
      redNoteComments: redNoteComments.filter(c => relevantPosts.some(p => p.id === c.postId)),
    };
  }

  // Electronics
  if (
    lowerMessage.includes("数码") ||
    lowerMessage.includes("电子") ||
    lowerMessage.includes("electronic")
  ) {
    const filtered = products.filter((p) => p.category === "数码电子");
    const relevantPosts = redNotePosts.filter(post => 
      filtered.some(p => p.id === post.productId)
    );
    return {
      message: "根据小红书社区评价，这些是评分最高的数码产品：",
      products: filtered.slice(0, 4),
      redNotePosts: relevantPosts.slice(0, 2),
      redNoteComments: redNoteComments.filter(c => relevantPosts.slice(0, 2).some(p => p.id === c.postId)),
    };
  }

  // Best/popular with social proof
  if (
    lowerMessage.includes("最好") ||
    lowerMessage.includes("推荐") ||
    lowerMessage.includes("热门") ||
    lowerMessage.includes("爆款") ||
    lowerMessage.includes("best") ||
    lowerMessage.includes("popular")
  ) {
    const popularPosts = redNotePosts.sort((a, b) => b.likes - a.likes).slice(0, 3);
    const popularProducts = products.filter(p => 
      popularPosts.some(post => post.productId === p.id)
    );
    return {
      message: "根据小红书点赞最多的评价，这些是大家都在讨论的爆款：",
      products: popularProducts,
      redNotePosts: popularPosts,
      redNoteComments: redNoteComments.filter(c => popularPosts.some(p => p.id === c.postId)),
    };
  }

  // Default response with community insights
  const topPosts = redNotePosts.sort((a, b) => b.likes - a.likes).slice(0, 2);
  const topProducts = products.filter(p => topPosts.some(post => post.productId === p.id));
  
  return {
    message:
      "很高兴帮你找东西！我会分析小红书的真实评价和用户体验，给你最好的推荐。\n\n你可以试试问：\n• '耳机评价怎么样？'\n• '热门商品有哪些？'\n• '办公笔记本推荐'\n\n或者上传图片找相似款！",
    products: topProducts,
    redNotePosts: topPosts,
    redNoteComments: redNoteComments.filter(c => topPosts.some(p => p.id === c.postId)),
  };
}
